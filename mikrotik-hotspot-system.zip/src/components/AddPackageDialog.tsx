import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';
import db from '@/lib/shared/kliv-database.js';

interface AddPackageDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

const AddPackageDialog = ({ open, onOpenChange, onSuccess }: AddPackageDialogProps) => {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [duration, setDuration] = useState('');
  const [speed, setSpeed] = useState('');
  const [dataLimit, setDataLimit] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name || !price || !duration) {
      toast({
        title: 'خطأ',
        description: 'يرجى ملء جميع الحقول المطلوبة',
        variant: 'destructive'
      });
      return;
    }

    setIsLoading(true);
    
    try {
      await db.insert('packages', {
        name: name,
        name_ar: name,
        price: parseFloat(price),
        duration_days: parseInt(duration),
        speed_limit: speed ? `${speed} Mbps` : null,
        download_limit: dataLimit ? `${dataLimit} GB` : null,
        simultaneous_users: 1,
        is_active: 1,
        sort_order: 0
      });
      
      toast({
        title: 'تمت إضافة الباقة',
        description: `تم إضافة ${name} بنجاح`
      });
      
      setName('');
      setPrice('');
      setDuration('');
      setSpeed('');
      setDataLimit('');
      onOpenChange(false);
      onSuccess?.();
    } catch (error) {
      console.log('Error adding package:', error);
      toast({
        title: 'خطأ',
        description: 'فشل في إضافة الباقة',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>إضافة باقة جديدة</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="name">اسم الباقة</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="مثال: باقة شهرية"
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="price">السعر ($)</Label>
              <Input
                id="price"
                type="number"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="50"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="duration">المدة (أيام)</Label>
              <Input
                id="duration"
                type="number"
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                placeholder="30"
                required
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="speed">السرعة (Mbps)</Label>
              <Input
                id="speed"
                type="number"
                value={speed}
                onChange={(e) => setSpeed(e.target.value)}
                placeholder="50"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="dataLimit">حد البيانات (GB)</Label>
              <Input
                id="dataLimit"
                type="number"
                value={dataLimit}
                onChange={(e) => setDataLimit(e.target.value)}
                placeholder="100"
                disabled={isLoading}
              />
            </div>
          </div>
          
          <div className="flex gap-3 pt-4">
            <Button 
              type="submit" 
              className="flex-1 gradient-primary text-white"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 ml-2 animate-spin" />
                  جاري الإضافة...
                </>
              ) : (
                'إضافة الباقة'
              )}
            </Button>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => onOpenChange(false)}
              disabled={isLoading}
            >
              إلغاء
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddPackageDialog;
